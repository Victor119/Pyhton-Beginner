def text_cap(text):
    return text.title()