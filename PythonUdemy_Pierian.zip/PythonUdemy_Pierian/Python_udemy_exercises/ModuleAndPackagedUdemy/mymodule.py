def my_func():
    print("Hey i am in mymodule.py")