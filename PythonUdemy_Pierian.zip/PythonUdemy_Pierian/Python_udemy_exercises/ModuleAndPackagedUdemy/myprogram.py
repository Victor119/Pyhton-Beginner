from MyMainPackage import  some_main_script
from MyMainPackage.SubPackage import mysubscript

some_main_script.report_main()

mysubscript.sub_report()