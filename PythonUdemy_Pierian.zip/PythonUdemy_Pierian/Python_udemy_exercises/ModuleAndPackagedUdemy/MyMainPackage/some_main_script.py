def report_main():
    print("Hey i am in some_main_script in main package.")