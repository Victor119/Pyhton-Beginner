def sub_report():
    print("Hey i am a function inside mysubscript.")