#from IPython.display import clear_output

sir1=" | | "
sir2="-----"

def print_matrix(board):
    print("{}|{}|{}".format(board[0],board[1],board[2]))
    print(sir2)
    print("{}|{}|{}".format(board[3], board[4], board[5]))
    print(sir2)
    print("{}|{}|{}".format(board[6], board[7], board[8]))

def insert_X_in_board(board,y):
    if (y == 1):
        board[6] = "x"
    if (y == 2):
        board[7] = "x"
    if (y == 3):
        board[8] = "x"
    if (y == 4):
        board[3] = "x"
    if (y == 5):
        board[4] = "x"
    if (y == 6):
        board[5] = "x"
    if (y == 7):
        board[0] = "x"
    if (y == 8):
        board[1] = "x"
    if (y == 9):
        board[2] = "x"
    return board

def insert_0_in_board(board,y):
    if (y == 1):
        board[6] = "0"
    if (y == 2):
        board[7] = "0"
    if (y == 3):
        board[8] = "0"
    if (y == 4):
        board[3] = "0"
    if (y == 5):
        board[4] = "0"
    if (y == 6):
        board[5] = "0"
    if (y == 7):
        board[0] = "0"
    if (y == 8):
        board[1] = "0"
    if (y == 9):
        board[2] = "0"
    return board

def scoate_din_lista(stiva, num):
    stiva.remove(num)
    return stiva

def verifica_daca_elementul_se_afla_in_lista(stiva, num):
    for num2 in stiva:
        if num2 == num:
            return True
    return False

def verif_if_x_or_0_is_winner(board):
    if ((board[6] == "x" and board[4] == "x" and board[2] == "x") or (board[8] == "x" and board[4] == "x" and board[0] == "x")):
        return True
    if ((board[6] == "0" and board[4] == "0" and board[2] == "0") or (board[8] == "0" and board[4] == "0" and board[0] == "0")):
        return True
    if ((board[0] == "x" and board[1] =="x" and board[2]=="x") or (board[3] == "x" and board[4] =="x" and board[5]=="x") or (board[6] == "x" and board[7] =="x" and board[8]=="x")):
        return True
    if ((board[0] == "0" and board[1] == "0" and board[2] == "0") or (board[3] == "0" and board[4] == "0" and board[5] == "0") or (board[6] == "0" and board[7] == "0" and board[8] == "0")):
        return True
    if ((board[0] == "x" and board[3] == "x" and board[6] == "x") or (board[1] == "x" and board[4] == "x" and board[7] == "x") or (board[2] == "x" and board[5] == "x" and board[8] == "x")):
        return True
    if ((board[0] == "0" and board[3] == "0" and board[6] == "0") or (board[1] == "0" and board[4] == "0" and board[7] == "0") or (board[2] == "0" and board[5] == "0" and board[8] == "0")):
        return True
    return False


def fa_primele_2_citiri(board):
    global verif
    global list
    z = input("Are you ready to play?Yes or No.")
    if (z == "Yes"):
        print('\n' * 100)
        y = input("Player1: do you wanna be with x or 0?")
        print('\n' * 100)
        if (y == "x" or y== "0"):
            t = y
            y = input("Player1: will be first.\n Choose a place(1-9): ")
            print('\n' * 100)
            a = int(y)
            if(verifica_daca_elementul_se_afla_in_lista(list,a) == True):
                board = insert_X_in_board(board, a)
                list = scoate_din_lista(list, a)
            else:
                return False
        else:
            return False
        print_matrix(board)
        y = input("Player2:\n Choose a place (1-9):")
        print('\n' * 100)
        a = int(y)
        if (verifica_daca_elementul_se_afla_in_lista(list, a) == True):
            list = scoate_din_lista(list, a)
        else:
            return False
        if (t == "x"):
            board = insert_0_in_board(board, a)
            verif = "0"
        if (t == "0"):
            board = insert_X_in_board(board, a)
            verif = "x"
        print_matrix(board)
    else:
        verif= verif+"False"

c = True
while c == True:
    verif = ""
    board = [" ", " ", " ", " ", " ", " ", " ", " ", " "]
    list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    fa_primele_2_citiri(board)
    if(verif != "False"):
        index = 3
        ok = True
        z=verif_if_x_or_0_is_winner(board)
        while (index < 10 and ok==True and z==False):
            ok2 = 0
            if(index % 2 ==1):
                player="1"
            else:
                player="2"
            x=input("Player{}:\n Choose a place (1-9):".format(player))
            print('\n' * 100)
            a = int(x)
            if(verifica_daca_elementul_se_afla_in_lista(list,a) == True):
                list = scoate_din_lista(list, a)
                if(verif == "x" and ok2 ==0):
                    board = insert_0_in_board(board, a)
                    verif = "0"
                    ok2 = ok2 + 1
                if(verif == "0" and ok2==0):
                    board = insert_X_in_board(board, a)
                    verif = "x"
                    ok2 = ok2 + 1
                print_matrix(board)
                index = index+1
                z = verif_if_x_or_0_is_winner(board)
                if(z == True):
                    print("Player{}: Is the winner".format(player))
                    sir = input("Do you want to play again?Enter Yes or No:")
                    if(sir == "No"):
                        c=False
                        ok=False
                    if(sir != "No" and sir!= "Yes"):
                        c=False
                        ok=False
            else:
                ok = False
                c = False
        if(index == 10 and z==False):
            print("It is Tie!")
            sir = input("Do you want to play again?Enter Yes or No:")
            if (sir == "No"):
                c = False
    else:
        c=False

