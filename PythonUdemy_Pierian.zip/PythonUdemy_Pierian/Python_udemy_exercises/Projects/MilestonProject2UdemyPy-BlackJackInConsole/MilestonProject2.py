from random import randint
class Account:

    def __init__(self,balance):
        self.balance = balance

    def show_balance(self):
        return self.balance

    def withdraw(self,sum):
        if(self.balance >= sum):
            self.balance = self.balance-sum
            return 0
        else:
            return 1

    def add_balance(self,sum):
        self.balance += sum

class Deck(Account):

    def __init__(self, balance, numberCards, cards):
        Account.__init__(self, balance)
        self.numberCards = numberCards
        self.cards = cards

    def withdraw_card(self):
        if(self.numberCards > 0):
            self.numberCards -= 1
            return 0
        else:
            return 1

def put_card_in_hand(num,hand):
    if(num==1 or num==14):
        hand = hand + "A"
    if (num == 2):
        hand = hand + "2"
    if (num == 3):
        hand = hand + "3"
    if (num == 4):
        hand = hand + "4"
    if (num == 5):
        hand = hand + "5"
    if (num == 6):
        hand = hand + "6"
    if (num == 7):
        hand = hand + "7"
    if (num == 8):
        hand = hand + "8"
    if (num == 9):
        hand = hand + "9"
    if (num == 10):
        hand = hand + "10"
    if(num==11):
        hand = hand + "J"
    if(num==12):
        hand = hand + "Q"
    if(num==13):
        hand = hand + "K"
    return hand

def hand_sum(hand):
    hand = hand.split(" ")
    sum = 0
    for num in hand:
        if num == "10" or num == "J" or num == "Q" or num == "K":
            sum = sum + 10
        if num == "2":
            sum = sum + 2
        if num == "3":
            sum = sum + 3
        if num == "4":
            sum = sum + 4
        if num == "5":
            sum = sum + 5
        if num == "6":
            sum = sum + 6
        if num == "7":
            sum = sum + 7
        if num == "8":
            sum = sum + 8
        if num == "9":
            sum = sum + 9
        if num == "A":
            if(sum + 11 > 21):
                sum = sum + 1
            else:
                sum = sum + 11
    return sum


def print_table(player_hand,player_sum,player_balance,player_bet,dealer_hand):
    print("________________________________________")
    print("|          Computer Dealer             |")
    print("|                  {}                   ".format(dealer_hand))
    print("|  ____                                |")
    print("| |    |                    Player Bet: ")
    print("| |DECK|                         {}     ".format(player_bet))
    print("| |____|                               |")
    print("|                  {}                   ".format(player_hand))
    print("|          PLAYER Sum:{}               |".format(player_sum))
    print("|             BALANCE:{}                ".format(player_balance))
    print("________________________________________")

def put_first_2_cards_in_hand(player_hand):
    player_card = randint(1, 14)
    player_hand = put_card_in_hand(player_card, player_hand)
    player_hand = player_hand + " "

    player_card = randint(1, 14)
    player_hand = put_card_in_hand(player_card, player_hand)
    player_hand = player_hand + " "
    return player_hand


cards = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
dealerAccount = Deck(5,52,cards)
print("Player incepe cu 2 carti si dealer la fel, doar ca poti sa vezi o carte din cele 2 ale lui.Numarul de pe carte reprezinta numarul de puncte al cartii cu exceptia J,Q,K care valoreaza 10 puncte ")
print("si A care valoreaza fie 1 fie 11  in functie de care e mai favorabil.Daca unul din jucatori(fie Player, fie Dealer) are mai mult de 21 de puncte a pierdut.Cartile si deciile dealerului se vad la final.")
print("Castigatorul este ales in functie de cel care este mai aproape de 21.(Daca ambii jucatori au peste 21 de puncte, atunci castigatorul este cel care este mai aproape de 21 de puncte ")
stop_repeat = 1
n = int(input("Insert the cuantity of money that you want to start to play with:"))
playerAccount = Account(n)
ok2 = 0

while (stop_repeat == 1 and playerAccount.balance>=0):

    if (ok2 == 1):
        print("Player balance is:{}".format(playerAccount.balance))
    n= int(input("Place your bet please:"))
    ok = 0
    while(ok == 0):
        if(playerAccount.withdraw(n) == 0):
            print("Permission granted!")
            player_bet = n
            ok = 1
        else:
            if (playerAccount.balance > 0):
                print("Permission denied! (Insuficient founds)")
                n = int(input("Place your bet please:"))

    player_stay = 0
    player_hand = ""

    dealer_stay = 0
    dealer_hand_original = ""
    dealer_hand_false = "X "

    player_hand = put_first_2_cards_in_hand(player_hand)
    player_sum = hand_sum(player_hand)

    dealer_hand_original = put_first_2_cards_in_hand(dealer_hand_original)
    index = 0
    dealer_hand_now=dealer_hand_original.split(" ")
    for num in dealer_hand_now:
        if(index >=1 ):
            dealer_hand_false = dealer_hand_false + num + " "
        index = index + 1
    dealer_sum = hand_sum(dealer_hand_original)

    print_table(player_hand,player_sum,playerAccount.show_balance(),player_bet,dealer_hand_false)

    while(player_stay == 0):
        player_input = int(input("Choose 1 to hit or 2 to stay:"))
        if(player_input == 1):
            player_card = randint(1,14)
            player_hand = put_card_in_hand(player_card,player_hand)
            player_hand = player_hand + " "
            player_sum = hand_sum(player_hand)
            print("\n" * 100)
            print_table(player_hand,player_sum,playerAccount.show_balance(),player_bet,dealer_hand_false)
        else:
            player_stay = 1

    while(dealer_stay == 0):
        if(player_sum > 21):
            print_table(player_hand,player_sum,playerAccount.show_balance(),player_bet,dealer_hand_original)
            dealer_stay = 1
        else:
            while(dealer_sum <= 16):
                dealer_card = randint(1,14)
                dealer_hand_original = put_card_in_hand(dealer_card,dealer_hand_original)
                dealer_hand_original = dealer_hand_original + " "
                dealer_sum = hand_sum((dealer_hand_original))
                print_table(player_hand,player_sum,playerAccount.show_balance(),player_bet,dealer_hand_original)
            else:
                dealer_stay=1
                print_table(player_hand, player_sum,playerAccount.show_balance(),player_bet,dealer_hand_original)
    if(dealer_sum>21 and player_sum>21 ):
        if ((dealer_sum - 21) < (player_sum - 21)):
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("Dealer Wins!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if(playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0
        elif((dealer_sum - 21) == (player_sum - 21)):
            playerAccount.add_balance(player_bet)
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("It is a draw!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if (playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0
        else:
            playerAccount.add_balance(player_bet*2)
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("Player Wins!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if (playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0
    elif(dealer_sum>21 and player_sum<=21):
        playerAccount.add_balance(player_bet*2)
        player_bet = 0
        print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
        print("Player Wins!\n Do you want to play again?")
        player_input = input("Yes or No:")
        if player_input in "No":
            stop_repeat = 0
        elif player_input in "Yes":
            if (playerAccount.balance == 0):
                stop_repeat = 0
                print("Inssuficient founds!")
            ok2 = 1
            print("\n" * 100)
        else:
            stop_repeat = 0
    elif(dealer_sum<=21 and player_sum>21):
        player_bet = 0
        print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
        print("Dealer Wins!\n Do you want to play again?")
        player_input = input("Yes or No:")
        if player_input in "No":
            stop_repeat = 0
        elif player_input in "Yes":
            if (playerAccount.balance == 0):
                stop_repeat = 0
                print("Inssuficient founds!")
            ok2 = 1
            print("\n" * 100)
        else:
            stop_repeat = 0
    else:
        if((21- dealer_sum) < (21-player_sum)):
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("Dealer Wins!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if (playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0
        elif((21-dealer_sum) == (21-player_sum)):
            playerAccount.add_balance(player_bet)
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("It is a draw!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if (playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0
        else:
            playerAccount.add_balance(player_bet*2)
            player_bet = 0
            print_table(player_hand, player_sum, playerAccount.show_balance(), player_bet, dealer_hand_original)
            print("Player Wins!\n Do you want to play again?")
            player_input = input("Yes or No:")
            if player_input in "No":
                stop_repeat = 0
            elif player_input in "Yes":
                if (playerAccount.balance == 0):
                    stop_repeat = 0
                    print("Inssuficient founds!")
                ok2 = 1
                print("\n" * 100)
            else:
                stop_repeat = 0


