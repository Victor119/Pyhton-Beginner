from mymodule.py import my_func

my_func()