def vol(rad):
    return 4/3*3.14*(rad**3)

def ran_check(num,low,high):
    return (low<=num and high>=num)

def up_low(sir):
    countU = 0 ; countL = 0
    for num in sir:
        if num.isupper() == True :
            countU = countU +1
        if num.islower() == True :
            countL = countL +1
    print("No. of Upper case characters : {}".format(countU))
    print("No. of Lower case Characters : {}".format(countL))

def unique_list(list):
     list=set(list)
     return list

def multiply(list):
    mul = 1
    for num in list:
        mul = mul * num
    return mul

def palindrome(sir):
    sir2=sir[::-1]
    return sir==sir2

import string

def ispangram(sir,alfabet = string.ascii_lowercase):
    stiva=[]
    for num in alfabet:
        stiva.append(num)

    ok=True
    while ok==True:
        ok=False
        if(len(stiva) > 0):
            for num in sir:
                if(stiva[0] == num):
                    ok=True
        if(ok==True):
            stiva.pop(0)
        else:
            if(len(stiva)==0):
                return True
            else:
                return False

print(ispangram("The quick brown fox jumps over the lazy dog"))
#print(palindrome("helle"))