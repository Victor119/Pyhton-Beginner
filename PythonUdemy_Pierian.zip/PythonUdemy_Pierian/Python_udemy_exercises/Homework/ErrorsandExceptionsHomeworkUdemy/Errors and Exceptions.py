'''
try:
    for i in ['a','b','c']:
        print(i**2)

except TypeError:
    print("except Handled")

try:
    x = 5
    y = 0
    z = x / y

except:
    print("except Handled")

finally:
    print("All Done")
'''

def ask():
    while True:
        try:
            num=int(input("Input an integer:"))
        except:
            print("An error occurred! Please try again!")
        else:
            print("Thank you, your number squared is:{}".format(num**2))
            break

ask()
