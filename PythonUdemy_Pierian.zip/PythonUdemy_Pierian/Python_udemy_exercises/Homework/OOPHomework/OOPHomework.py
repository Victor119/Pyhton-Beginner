class Line:
    def __init__(self,coor1,coor2):
        self.coor1=coor1
        self.coor2=coor2

    def distance(self):
        return (((self.coor2[0]-self.coor1[0])*(self.coor2[0]-self.coor1[0]))+((self.coor2[1]-self.coor1[1])*(self.coor2[1]-self.coor1[1])))**0.5

    def slope(self):
        return (self.coor2[1]-self.coor1[1])/(self.coor2[0]-self.coor1[0])

coordinate1 = (3,2)
coordinate2 = (8,10)

li = Line(coordinate1,coordinate2)

class Cylinder:
    pi=3.14

    def __init__(self,height,radius):
        self.height=height
        self.radius=radius

    def volume(self):
        return self.pi*self.radius*self.radius*self.height

    def aria_baza(self):
        return self.pi*self.radius*self.radius

    def aria_laterala(self):
        return 2*self.pi*self.radius*self.height

    def aria(self):
        return 2*self.aria_baza()+self.aria_laterala()

c = Cylinder(2,3)

print(c.aria())
