import random
'''
def gensquares(n):
    for x in range(int(n**(1/2)+1)):
        yield x**2

for i in gensquares(10):
    print(i)

def random_number(low,high,n):
    for i in range(n):
        yield random.randint(low,high)

for x in random_number(10,30, 12):
    print(x)

s= "Hello"
s_iter=iter(s)
for i in range(5):
    print(next(s_iter))
'''
