#WarmUP
def lesser_of_two_evens(num1,num2):
    if(num1 % 2 == 0 and num2 % 2 == 0):
        if(num1 < num2):
            return num1
        else:
            return num2
    if((num1 % 2 == 0 and num2 % 2 == 1) or (num1 % 2 == 1 and num2 % 2 == 0) or (num1 % 2 == 1 and num2 % 2 == 1)):
        if(num1 > num2):
            return num1
        else:
            return num2


def animal_crackers(sir):
    sir = sir.lower()
    sir = sir.split()
    if(sir[0][0] == sir[1][0]):
        return True
    else:
        return False


def makes_twenty(num1 , num2):
    if((num1 + num2 == 20) or (num1 == 20) or (num2 == 20)):
        return True
    else:
        return False


#Level1
def old_macdonald(sir):
    sir2 = sir[0:1]
    sir2 = sir2.upper()
    sir = sir2 + sir[1:]
    sir2 = sir[0:3]
    sir3 = sir[3:4]
    sir3 = sir3.upper()
    sir = sir2 + sir3 + sir[4:]
    return sir


def master_yoda(sir):
    sir2 = sir[0]
    return sir[-1:0:-1]+sir2


def almost_there(num):
    num= abs(num)
    if(num<100 or (num>100 and num%10!=0 and num<200) or (num>200 and num%10!=0)):
        return True
    else:
        return False


#Level2
def has_33(list):
    ok = 0
    for num in list:
        if(ok == 1):
            if(x == num):
                return True
            else:
                ok = 0
        if(ok == 0):
            if(num == 3):
                x = 3
                ok = ok+1
    return False


def paper_doll(sir):
    sir2=""
    for num in sir:
        sir2=sir2 + (num * 3)
    return  sir2


def blackjack(num1 , num2 ,num3):
    sum = num1 + num2 + num3
    if(sum <= 21):
        return sum
    if(sum > 21 and (num1 == 11 or num2 == 11 or num3==11)):
        sum = sum - 10
    if(sum > 21):
        return "BUZZ"
    else:
        return sum


def summer_69(list):
    sum = 0
    ok = 0
    for num in list:
        if(num == 6):
            ok = ok+1
        if(ok==0):
            sum = sum+num
        if(num == 9):
            ok = 0
    return sum


#Challenging Problems
def spy_game(list):
    count0 = 0
    for num in list:
        if(num == 0):
            count0 = count0+1
        if(num == 7):
            if(count0 >= 2):
                return True
    return False


def count_primes(numar):
    count = 0
    if(numar == 2):
        return 1
    if(numar == 3):
        return 2
    if(numar > 3):
        count = 2
    for num in range(4,(numar+1)):
        ok = 0
        valoare = int(num ** 0.5 +1)
        for num2 in range(2,valoare):
            if(num % num2 ==0):
                ok = 1
        if(ok == 0):
            count = count + 1
    return count


def print_big(sir):
    dictionary={"a":["*"," "," "," "," "],}

sir2 = count_primes()
print(sir2)

