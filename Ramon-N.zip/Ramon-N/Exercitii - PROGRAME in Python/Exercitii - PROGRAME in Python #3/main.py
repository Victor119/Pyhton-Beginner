'''
1) Creeaza un program care determina daca un numar (introdus de la tastatura)
este par sau impar. Se va afisa (print) in terminal un mesaj similar cu:
"Numarul introdus X este par", in cazul in care numarul este par,
iar "Numarul nu este par" in rest.


number = int(input("Insert a number: "))
if(number % 2 == 0):
    print("Numarul introdus {} este par".format(number))
else:
    print("Numarul nu este par")

2) Creeaza un chestionar de intrebari pe care o persoana din departamentul
de resurse umane le poate adresa la interviul de angajare. Vor exista 5
intrebari (similare cu cele de mai jos) pe care le vei adresa persoanei care
va rula programul si care va putea sa le raspunda prin inputul sau de la
tastatura. In timpul executiei programului, acesta stocheaza datele, iar
la sfarsitul acestor intrebari se vor afisa sub forma urmatoare:

"Canditatul X, a raspuns astfel la intrebarile de mai sus: ..."

Intrebarile: "Cum te numesti ?", "Ce job iti doresti ?",
"In cat timp crezi ca poti obtine acest job ?",
"Care sunt pasii pe care trebuie sa-i urmezi pentru a te putea angaja ?",
"De cand doresti sa incepi ?".

list = []
str = input("Cum te numesti ?")
list.append(str)
str = input("Ce job iti doresti ?")
list.append(str)
str = input("In cat timp crezi ca poti obtine acest job ?")
list.append(str)
str = input("Care sunt pasii pe care trebuie sa-i urmezi pentru a te putea angaja ?")
list.append(str)
str = input("De cand doresti sa incepi ?")
list.append(str)
for i in range(0,5):
    print(list[i])

3) Creeaza un program care determina daca un cuvant (string) introdus de catre
utilizator (de la tastatura) este Palindrom sau nu. Un palindrom este un sir
de caractere care citit de la stanga la dreapta sau de la dreapta la stanga
ramane neschimbat.

Exemplu: lupul, capac, apa - toate se citeste la fel din ambele parti

str = input("Introduceti cuvant pentru a verifica proprietatea:")
str2  = str[::-1]
if(str == str2):
    print("Sirul este Palindrom")
else:
    print("Sirul nu este Palindrom")

'''