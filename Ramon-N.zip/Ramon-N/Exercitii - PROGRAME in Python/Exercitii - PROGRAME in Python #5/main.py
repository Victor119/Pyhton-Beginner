'''
Bine ai revenit la o noua runda de exercitii practice. Iata ce iti sugerez sa faci de data
aceasta (folosind functii in Python):

1) Creeaza un program care contorizeaza si afiseaza in terminal numarul de caractere al
urmatoarelor cuvinte. Programul trebuie sa contina cel putin o functie.

Exemplu: "programare", "python", "eu stiu sa programez si imi place ceea ce fac",
"sunt entuziasmat"

def count_char(str):
    list = str.split(" ")
    for i in list:
        print(len(i))

str = input("Introduce-ti un sir")
count_char(str)

2) Creeaza un program (care va contine o functie :D ) care pentru orice numar (sau string)
introdus va intoarce inversul acelui numar.

Exemplu: invers(1234) => 4321, invers ("python") => nohtyp

def reverse_input(str):
    print(str[::-1])

str=input("Introduceti valoare pentru a fi inversata : ")
reverse_input(str)

'''
