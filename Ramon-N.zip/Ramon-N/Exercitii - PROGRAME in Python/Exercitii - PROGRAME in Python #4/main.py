'''
1.1) Calculati suma tuturor numerelor de la 1 la 100. Creati o varianta a programului
folosind bucle for, iar alta varianta folosind bucle while. Afisati rezultatul pe ecran
intr-un format precum: "Suma numerelor de A la Z este... ".

suma =0
for i in range(1,101):
    suma = suma + i
print(suma)

i=1
while i < 101:
    suma = suma +i
    i += 1
print(suma)

1.2) Dinamizati programul prin adaugarea optiunii de introducere a celor 2 numere
(nr. de inceput si cel de sfarsit) de la tastatura.

a = int(input())
b = int(input())

suma =0
for i in range(a,b+1):
    suma = suma + i
print(suma)

i=a
while i < b+1:
    suma = suma +i
    i += 1
print(suma)

2) Creati un joc Hartie-Piatra-Foarfece la care participa 2 persoane.
(Nota: folositi-va de functia "input()" pentru a cere date de la jucatori; in momentul
cand cineva castiga, printati un mesaj de felicitare si intrebati utilizatorii daca
sa inceapa un joc nou)

ok=True
while ok==True:
    player1 = input("Insert your choice")
    player2 = input("Insert your choice")
    if(player1 == "hartie" and player2 == "piatra"):
        print("player1 castiga")
    if(player1 == "hartie" and player2 == "foarfec"):
        print("player2 castiga")
    if(player1 == "hartie" and player2 == "hartie"):
        print("este egalitate")
    if(player1 == "piatra" and player2 == "hartie"):
        print("player2 castiga")
    if(player1 == "piatra" and player2 == "foarfec"):
        print("player1 castiga")
    if(player1 == "piatra" and player2 == "piatra"):
        print("este egalitate")
    if(player1 == "foarfec" and player2 == "hartie"):
        print("player1 castiga")
    if(player1 == "foarfec" and player2 == "foarfec"):
        print("este egalitate")
    if(player1 == "foarfec" and player2 == "piatra"):
        print("player2 castiga")
    ans = input("Do you wanna play againa? Yes or No?")
    if(ans == "No"):
        ok=False
'''
