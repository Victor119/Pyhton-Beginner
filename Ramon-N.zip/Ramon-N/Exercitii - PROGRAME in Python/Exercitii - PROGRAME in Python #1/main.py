notA = -1
test = 7.23
curs = "Introducere in Programare"

print(type(notA),type(test),type(curs))
