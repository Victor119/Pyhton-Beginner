

sir1 = input("Introduceti numele:")
sir2 = int(input("Introduceti varsta:"))
sir2 = 2020 - sir2 + 100
print(sir1 + "veti implini varsta de 100 de ani in anul: {}".format(sir2))

sir1 = input("Introduceti numele:")
sir2 = int(input("Introduceti varsta:"))
sir2 = 2020 - sir2 + 100
print(sir1 + "veti implini varsta de 100 de ani in anul: {}".format(sir2))

sir1 = input("Introduceti numele:")
sir2 = int(input("Introduceti varsta:"))
sir2 = 2020 - sir2 + 100
print(sir1 + "veti implini varsta de 100 de ani in anul: {}".format(sir2))