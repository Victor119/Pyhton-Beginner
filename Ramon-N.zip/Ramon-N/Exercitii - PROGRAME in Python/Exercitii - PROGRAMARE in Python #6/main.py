'''
Si acum sa trecem la partea de exercitii in care ne vom "juca" cu listele si
tuplurile in Python.

1) Sa spunem aceasta lista salvata intr-o variabila:
a = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]. Scrieti o linie de Python care
ia aceasta lista a si face o lista noua care contine doar elementele pare
ale acestei liste.

a= [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
list = a[1::2]
print(list)

2.1) Creati o lista cu numele a 10 prieteni (numele nu trebuie sa fie
distincte). Respectand ordinea, rezolvati urmatoarele cerinte:

Sortati lista de nume.
Utilizand o lista auxiliara, determinati numarul de aparitii al fiecarui nume.
Determinati numele care apare de cele mai multe ori in lista initiala.
Determinati numele care apar cel mai putin ori in lista initiala.
Revenind la lista initiala de nume, inversati ordinea elementelor.

list = ['Ana' , 'Bianca' , 'Cristina' , 'Daria' , 'Elena' , 'Francisa' , 'Ioana' , 'Janna' , 'Lacramioara' , 'Maria']
list.sort()
list2 = []
list3 = []
count = 0
maxi = 0
mini = 999
for i in list:
    for j in list:
        if i == j:
            count += 1
    if maxi < count:
        maxi = count
    if mini > count:
        mini = count
    list2.append(count)
    list3.append(count)
    print(count)
    count = 0

count = 0
for i in list2:
    if list2[count] == maxi:
        print(list[count])
    count += 1

count = 0
for i in list3:
    if list3[count] == mini:
        print(list[count])
    count += 1

list.reverse()
print(list)

2.2) Formati perechi de cate 2 persoane cu numele din lista initiala si
impartiti aceste perechi (in mod egal) in 2 liste. Asigurati-va ca acestor
perechi nu li se poate modifica valoarea (hint: tupluri). Avand aceste
perechi, calculati numarul total de caractere pentru fiecare pereche in
parte si creati o lista noua in care sa le introduceti in ordine
descrescatoare.

'''


def run(command):
    com_p = subprocess.Popen([command], stdout=None, shell=True)
    com_p.wait()

    print com_p
